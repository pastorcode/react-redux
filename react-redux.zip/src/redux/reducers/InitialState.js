export default {
    courses: [], authors: []
}