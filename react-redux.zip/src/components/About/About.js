import React from 'react'
// import {Link} from 'react-router-dom'


const About = () => {
    return ( 
        <>
            <h2>About</h2>
            <p>This app uses React, Redux, React Router and other helpful library</p>
        </>
     );
}
 
export default About;